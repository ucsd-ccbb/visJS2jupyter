from setuptools import setup, find_packages
from codecs import open
from os import path

here = path.abspath(path.dirname(__file__))

# Get the long description from the README file
with open(path.join(here, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name = "visJS-2-jupyter",
    version = "16.8.26",
    description= "visJS_2_jupyter is a tool to bring the interactivity of networks created with vis.js into jupyter notebook cells",
    long_description=long_description,
    url = "http://visjs.org/docs/network/",
    author="Brin Rosenthal (sbrosenthal@ucsd.edu), Mikayla Webster (m1webste@ucsd.edu), Aaron Gary (agary@ucsd.edu)",
    license = 'MIT',
    classifiers=[
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 2',
    ],
    packages=find_packages(),
    install_requires=["IPython.display", "matplotlib", "numpy", "pandas", "networkx"]
)
